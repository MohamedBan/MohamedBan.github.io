// class InputHandler {
//   constructor(imageGrid, autoplay, colorFill){
//     this.imageGrid = imageGrid;
//     this.autoplay = autoplay;
//     this.colorFill = colorFill;

    
//     if (key === "e") {
//       this.imageGrid = create2dArray(COLS, ROWS);
//     }
//     if (key === "f") {
//       this.imageGrid = family;
//     }
//     if (key === "r") {
//       if (this.imageGrid === family){
//         alert("you win");
//       }
//     }
      
//     if (key === "a") {
//       this.autoplay = !this.autoplay;
//     }
        
//     if (!isNaN(key)) {
//       if (Number(key) < 9){
//         this.colorFill = colorObject[Number(key)];
//       }
      
//     }

//   }
// }